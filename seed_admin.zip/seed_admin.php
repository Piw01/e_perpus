<?php
// seed_admin.php (Diletakkan di folder ROOT proyek, sejajar dengan folder src dan public)

// 1. Definisikan Base Path (diperlukan untuk mencapai file config)
// __DIR__ adalah lokasi saat ini (folder e_perpus)
define('ROOT_PATH', __DIR__ . '/');

// 2. Muat file koneksi database
// Pastikan file src/config/Database.php sudah benar isinya
require_once ROOT_PATH . 'src/config/Database.php';

// ---------------------------------------------------
// DATA ADMIN AWAL UNTUK TESTING
// ---------------------------------------------------
$admin_data = [
    'nama_lengkap' => 'Administrator E-Perpus',
    'username'     => 'admin',        // Username yang akan digunakan untuk login
    'password'     => '123456'        // Password plain text untuk testing
];

echo "<h2>Script Seeder Data Admin Awal</h2>";

try {
    // 3. Inisialisasi Koneksi PDO
    $database = new Database();
    $db = $database->getConnection();

    // 4. Cek apakah tabel admin sudah memiliki data
    $check_query = "SELECT COUNT(*) FROM admin";
    $count_stmt = $db->query($check_query);
    if ($count_stmt->fetchColumn() > 0) {
        echo "<p style='color: orange;'>⚠️ Tabel admin sudah terisi. Seeding dibatalkan untuk menghindari duplikasi.</p>";
        exit;
    }

    // 5. 🔑 HASHING PASSWORD (Wajib untuk keamanan)
    // password_hash() akan mengenkripsi '123456' menjadi string panjang yang aman
    $hashed_password = password_hash($admin_data['password'], PASSWORD_DEFAULT);
    
    // 6. Query INSERT
    $query = "INSERT INTO admin (nama_lengkap, username, password) 
              VALUES (:nama_lengkap, :username, :password)";
    
    $stmt = $db->prepare($query);
    
    // Bind parameter menggunakan PDO Prepared Statement
    $stmt->bindParam(':nama_lengkap', $admin_data['nama_lengkap']);
    $stmt->bindParam(':username', $admin_data['username']);
    $stmt->bindParam(':password', $hashed_password); // Simpan yang sudah di-hash!
    
    // 7. Eksekusi
    if ($stmt->execute()) {
        echo "<p style='color: green;'>✅ Data admin berhasil ditambahkan!</p>";
        echo "<p>Anda sekarang bisa login dengan detail berikut:</p>";
        echo "<ul>";
        echo "<li><b>Username:</b> <code>{$admin_data['username']}</code></li>";
        echo "<li><b>Password:</b> <code>{$admin_data['password']}</code></li>";
        echo "</ul>";
        echo "<p>Silakan coba login di: <a href='public/index.php?page=auth/login'>http://localhost/e_perpus/public/index.php?page=auth/login</a></p>";
    } else {
         echo "<p style='color: red;'>❌ Gagal menambahkan data admin.</p>";
    }

} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Terjadi kesalahan koneksi atau query. Pastikan database <b>'perpus_satu'</b> sudah dibuat dan server MySQL sudah aktif.</p>";
    echo "<p>Pesan Error: " . $e->getMessage() . "</p>";
}
?>