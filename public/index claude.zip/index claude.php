<?php
/**
 * File Index Utama - Front Controller Pattern
 * Semua request akan melewati file ini
 */

// Start session
session_start();

// Load konfigurasi database
require_once __DIR__ . '/../src/config/database.php';

// Load semua model
require_once __DIR__ . '/../src/models/User.php';
require_once __DIR__ . '/../src/models/Kategori.php';
require_once __DIR__ . '/../src/models/Penulis.php';
require_once __DIR__ . '/../src/models/Penerbit.php';
require_once __DIR__ . '/../src/models/Siswa.php';
require_once __DIR__ . '/../src/models/Buku.php';
require_once __DIR__ . '/../src/models/Peminjaman.php';
require_once __DIR__ . '/../src/models/Pengadaan.php';

// Load semua controller
require_once __DIR__ . '/../src/controllers/AuthController.php';
require_once __DIR__ . '/../src/controllers/DashboardController.php';
require_once __DIR__ . '/../src/controllers/KategoriController.php';
require_once __DIR__ . '/../src/controllers/PenulisController.php';
require_once __DIR__ . '/../src/controllers/PenerbitController.php';
require_once __DIR__ . '/../src/controllers/SiswaController.php';
require_once __DIR__ . '/../src/controllers/BukuController.php';
require_once __DIR__ . '/../src/controllers/PeminjamanController.php';
require_once __DIR__ . '/../src/controllers/PengadaanController.php';

// Routing sederhana
$page = isset($_GET['page']) ? $_GET['page'] : 'login';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';

// Database instance
$database = new Database();
$db = $database->getConnection();

// Routing berdasarkan page
switch($page) {
    case 'login':
        $controller = new AuthController($db);
        if($action == 'process') {
            $controller->login();
        } else {
            $controller->showLogin();
        }
        break;
    
    case 'logout':
        $controller = new AuthController($db);
        $controller->logout();
        break;
    
    case 'dashboard':
        $controller = new DashboardController($db);
        $controller->index();
        break;
    
    case 'kategori':
        $controller = new KategoriController($db);
        switch($action) {
            case 'index':
                $controller->index();
                break;
            case 'create':
                $controller->create();
                break;
            case 'store':
                $controller->store();
                break;
            case 'edit':
                $controller->edit();
                break;
            case 'update':
                $controller->update();
                break;
            case 'delete':
                $controller->delete();
                break;
            default:
                $controller->index();
        }
        break;
    
    case 'penulis':
        $controller = new PenulisController($db);
        switch($action) {
            case 'index':
                $controller->index();
                break;
            case 'create':
                $controller->create();
                break;
            case 'store':
                $controller->store();
                break;
            case 'edit':
                $controller->edit();
                break;
            case 'update':
                $controller->update();
                break;
            case 'delete':
                $controller->delete();
                break;
            default:
                $controller->index();
        }
        break;
    
    case 'penerbit':
        $controller = new PenerbitController($db);
        switch($action) {
            case 'index':
                $controller->index();
                break;
            case 'create':
                $controller->create();
                break;
            case 'store':
                $controller->store();
                break;
            case 'edit':
                $controller->edit();
                break;
            case 'update':
                $controller->update();
                break;
            case 'delete':
                $controller->delete();
                break;
            default:
                $controller->index();
        }
        break;
    
    case 'siswa':
        $controller = new SiswaController($db);
        switch($action) {
            case 'index':
                $controller->index();
                break;
            case 'create':
                $controller->create();
                break;
            case 'store':
                $controller->store();
                break;
            case 'edit':
                $controller->edit();
                break;
            case 'update':
                $controller->update();
                break;
            case 'delete':
                $controller->delete();
                break;
            default:
                $controller->index();
        }
        break;
    
    case 'buku':
        $controller = new BukuController($db);
        switch($action) {
            case 'index':
                $controller->index();
                break;
            case 'create':
                $controller->create();
                break;
            case 'store':
                $controller->store();
                break;
            case 'edit':
                $controller->edit();
                break;
            case 'update':
                $controller->update();
                break;
            case 'delete':
                $controller->delete();
                break;
            default:
                $controller->index();
        }
        break;
    
    case 'peminjaman':
        $controller = new PeminjamanController($db);
        switch($action) {
            case 'index':
                $controller->index();
                break;
            case 'create':
                $controller->create();
                break;
            case 'store':
                $controller->store();
                break;
            case 'kembalikan':
                $controller->kembalikan();
                break;
            case 'process_return':
                $controller->processReturn();
                break;
            case 'delete':
                $controller->delete();
                break;
            default:
                $controller->index();
        }
        break;
    
    case 'pengadaan':
        $controller = new PengadaanController($db);
        switch($action) {
            case 'index':
                $controller->index();
                break;
            case 'create':
                $controller->create();
                break;
            case 'store':
                $controller->store();
                break;
            case 'edit':
                $controller->edit();
                break;
            case 'update':
                $controller->update();
                break;
            case 'delete':
                $controller->delete();
                break;
            default:
                $controller->index();
        }
        break;
    
    default:
        $controller = new AuthController($db);
        $controller->showLogin();
        break;
}
?>