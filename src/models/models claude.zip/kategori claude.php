<?php
/**
 * Model Kategori - untuk operasi CRUD data kategori buku
 */

class Kategori {
    private $conn;
    private $table = "kategori";

    public $id_kategori;
    public $nama_kategori;
    public $keterangan;

    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Mendapatkan semua kategori
     */
    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY nama_kategori ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Mendapatkan kategori berdasarkan ID
     */
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id_kategori = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Menghitung total kategori
     */
    public function count() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }

    /**
     * Membuat kategori baru
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (nama_kategori, keterangan) 
                  VALUES (:nama_kategori, :keterangan)";
        
        $stmt = $this->conn->prepare($query);

        // Sanitasi input
        $this->nama_kategori = htmlspecialchars(strip_tags($this->nama_kategori));
        $this->keterangan = htmlspecialchars(strip_tags($this->keterangan));

        $stmt->bindParam(':nama_kategori', $this->nama_kategori);
        $stmt->bindParam(':keterangan', $this->keterangan);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Update kategori
     */
    public function update() {
        $query = "UPDATE " . $this->table . " 
                  SET nama_kategori = :nama_kategori,
                      keterangan = :keterangan
                  WHERE id_kategori = :id";
        
        $stmt = $this->conn->prepare($query);

        // Sanitasi input
        $this->nama_kategori = htmlspecialchars(strip_tags($this->nama_kategori));
        $this->keterangan = htmlspecialchars(strip_tags($this->keterangan));