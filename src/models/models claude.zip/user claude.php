<?php
/**
 * Model User - untuk autentikasi dan manajemen user
 */

class User {
    private $conn;
    private $table = "users";

    public $id_user;
    public $username;
    public $password;
    public $nama_lengkap;
    public $email;
    public $role;
    public $status;

    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Login user dengan username dan password
     */
    public function login($username, $password) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE username = :username AND status = 'aktif' 
                  LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Verifikasi password
            if(password_verify($password, $row['password'])) {
                return $row;
            }
        }
        
        return false;
    }

    /**
     * Mendapatkan semua user
     */
    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Mendapatkan user berdasarkan ID
     */
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id_user = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Membuat user baru
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (username, password, nama_lengkap, email, role, status) 
                  VALUES (:username, :password, :nama_lengkap, :email, :role, :status)";
        
        $stmt = $this->conn->prepare($query);

        // Hash password
        $hashed_password = password_hash($this->password, PASSWORD_DEFAULT);

        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':nama_lengkap', $this->nama_lengkap);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':role', $this->role);
        $stmt->bindParam(':status', $this->status);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Update user
     */
    public function update() {
        if(!empty($this->password)) {
            $query = "UPDATE " . $this->table . " 
                      SET username = :username, 
                          password = :password,
                          nama_lengkap = :nama_lengkap,
                          email = :email,
                          role = :role,
                          status = :status
                      WHERE id_user = :id";
        } else {
            $query = "UPDATE " . $this->table . " 
                      SET username = :username,
                          nama_lengkap = :nama_lengkap,
                          email = :email,
                          role = :role,
                          status = :status
                      WHERE id_user = :id";
        }
        
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':nama_lengkap', $this->nama_lengkap);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':role', $this->role);
        $stmt->bindParam(':status', $this->status);
        $stmt->bindParam(':id', $this->id_user);

        if(!empty($this->password)) {
            $hashed_password = password_hash($this->password, PASSWORD_DEFAULT);
            $stmt->bindParam(':password', $hashed_password);
        }

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Hapus user
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id_user = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Cek apakah username sudah ada
     */
    public function isUsernameExists($username, $excludeId = null) {
        if($excludeId) {
            $query = "SELECT id_user FROM " . $this->table . " 
                      WHERE username = :username AND id_user != :id LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':id', $excludeId);
        } else {
            $query = "SELECT id_user FROM " . $this->table . " 
                      WHERE username = :username LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $username);
        }
        
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }
}
?>